## Rule details

This rule prevents using the `img` tag directly and suggests using the [`Image`](/docs/components/primitive/image.md) component from `@shopify/hydrogen`.
