export {preferGQL} from './prefer-gql';
