# Prevent `useQuery` in client components

The `useQuery` hook doesn't function in client components because it requires access to server-only features that don't exist in the client.
