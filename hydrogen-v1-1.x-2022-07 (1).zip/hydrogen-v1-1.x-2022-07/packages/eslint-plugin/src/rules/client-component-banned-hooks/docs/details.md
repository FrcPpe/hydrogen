## Rule details

This rule prevents using the `useQuery` hook in files that end with the `.client` extension.
