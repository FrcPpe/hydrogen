export {serverComponentBannedHooks} from './server-component-banned-hooks';
