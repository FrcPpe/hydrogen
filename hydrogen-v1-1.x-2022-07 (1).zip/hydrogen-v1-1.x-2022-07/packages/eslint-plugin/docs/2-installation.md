## Installation

Run the following command to install [ESLint](https://eslint.org/) and the ESLint plugin:

{% codeblock terminal %}

```bash
yarn add --dev eslint eslint-plugin-hydrogen
```

{% endcodeblock %}
