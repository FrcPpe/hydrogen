export {StarRating} from './StarRating.js';
