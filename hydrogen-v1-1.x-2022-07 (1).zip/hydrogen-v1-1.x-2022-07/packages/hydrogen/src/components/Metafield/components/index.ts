export {StarRating} from './StarRating/index.js';
