// This file is only used for e2e test "node-dev"
// because Jest 26 does not follow package.json#exports.
module.exports = require('./dist/node/framework/plugin');
