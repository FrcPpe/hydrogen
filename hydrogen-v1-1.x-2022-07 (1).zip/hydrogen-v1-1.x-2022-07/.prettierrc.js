module.exports = {
  ...require('@shopify/prettier-config'),
  tabWidth: 2,
  printWidth: 80,
  trailingComma: 'es5',
};
