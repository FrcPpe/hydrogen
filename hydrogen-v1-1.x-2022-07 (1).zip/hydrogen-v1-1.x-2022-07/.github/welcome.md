Documentation for Hydrogen is now available at https://shopify.dev/custom-storefronts/hydrogen.
