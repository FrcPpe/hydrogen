import Layout from '../components/Layout.server';
export default function Index({response}) {
  return (
    <Layout>
      <p>Meta Pixel example</p>
    </Layout>
  );
}
