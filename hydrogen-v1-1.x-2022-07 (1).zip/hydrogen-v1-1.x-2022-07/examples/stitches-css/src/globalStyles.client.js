import {globalCss} from '../stitches.config';

export default globalCss({
  '*': {
    margin: 0,
    padding: 0,
  },
});
