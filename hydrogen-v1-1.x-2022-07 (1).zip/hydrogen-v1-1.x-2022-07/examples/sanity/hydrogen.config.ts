import {defineConfig} from '@shopify/hydrogen/config';

export default defineConfig({
  shopify: {
    storeDomain: 'oxygenator.myshopify.com',
    storefrontToken: '87f9f62622ee57ee7fe8beaf50ecedb9',
    storefrontApiVersion: '2022-07',
  },
});
