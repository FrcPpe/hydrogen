export const sanityConfig = {
  apiVersion: 'v2022-05-01',
  dataset: 'production',
  projectId: 'g2b4qblu',
  useCdn: true,
};
