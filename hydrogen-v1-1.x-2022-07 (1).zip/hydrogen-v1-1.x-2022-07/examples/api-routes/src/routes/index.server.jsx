export default function Index({response}) {
  return response.redirect('/newsletter');
}
