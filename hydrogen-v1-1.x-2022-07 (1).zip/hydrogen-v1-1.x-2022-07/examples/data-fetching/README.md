# Data Fetching Example

An example of fetching data on Hydrogen.

- Storefront API
- Simple third party fetch
- Third party library

## Getting started

1. Clone this example.

```bash
npx degit Shopify/hydrogen/examples/data-fetching hydrogen-app
yarn
yarn dev
```

2. Open the app in the browser.
